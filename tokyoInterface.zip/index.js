window.onload = () => {
  const data = {};
  const $ = window.document.querySelector.bind(window.document);
};
